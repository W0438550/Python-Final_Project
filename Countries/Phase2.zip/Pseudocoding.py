#Final Project pseudocoding 
#Phase1
#Use a widget list for the country lists
#Use a label for the country names
#Use a label to display the Population
#Use a line edit box to allow the output of the Population
#Use a push button box to allow update of the Population
#Use a label for the total area
#use a combo box to display the value of the area in square miles and kilometres
#use a label  